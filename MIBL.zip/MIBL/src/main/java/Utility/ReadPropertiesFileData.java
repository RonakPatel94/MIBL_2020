package Utility;

import BasePage.BaseClass;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class ReadPropertiesFileData extends BaseClass {
    //public WebDriver driver;
    private Properties prop = null;

    public ReadPropertiesFileData() {
        super();
    }

    public void readPropertiesFile() {
        prop = new Properties();
        try {
            InputStream input = new
                    FileInputStream("src/main/resources/MIBLReaddata.properties");
            prop.load(input);

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public String getPropertyValue(String key) {
        return prop.getProperty(key);
    }

}

