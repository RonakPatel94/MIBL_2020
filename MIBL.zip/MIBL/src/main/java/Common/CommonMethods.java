package Common;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Random;

public class CommonMethods {
    public static Properties prop;
    //private Properties prop = null;
    private WebDriver driver;

    public CommonMethods(WebDriver driver) {
        this.driver = driver;
    }

    public boolean clickOnLinkOrButton(By by) {
        try {
            Thread.sleep(1000);
            WebElement generic_WebL = (new WebDriverWait(driver, 60))
                    .until(ExpectedConditions.visibilityOfElementLocated(by));
            generic_WebL.click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public boolean clickByJS(By by) {
        try {
            Thread.sleep(1000);
            WebElement webElement = (new WebDriverWait(driver, 60))
                    .until(ExpectedConditions.visibilityOfElementLocated(by));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", webElement);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public boolean MouseOver(By by) {
        try {
            Thread.sleep(2000);
            Actions actObj = new Actions(driver);
            actObj.moveToElement((WebElement) by).build().perform();
            return true;
        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean selectFromDropDown(By by,String data) {
        try {
            Thread.sleep(1000);
            Select selectRule = new Select((new WebDriverWait(driver, 30))
                    .until(ExpectedConditions.visibilityOfElementLocated(by)));
            selectRule.selectByVisibleText(String.valueOf(data));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public boolean BootstrapDropDown(By by) {
        try {
            Thread.sleep(1000);
            Select selectRule = new Select((new WebDriverWait(driver, 30))
                    .until(ExpectedConditions.visibilityOfElementLocated(by)));
            selectRule.selectByVisibleText(String.valueOf(by));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public boolean enterTextInInputField(By by, String data) throws InterruptedException {
        Thread.sleep(1000);
        try {
            WebElement generic_WebL = (new WebDriverWait(driver, 60))
                    .until(ExpectedConditions.visibilityOfElementLocated(by));
            if (generic_WebL.isDisplayed())
            {
                generic_WebL.clear();
                generic_WebL.sendKeys(data);
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean verifyElementIsVisible(By by) {
        try {
            Thread.sleep(10000);
            WebElement generic_WebL = driver.findElement(by);
            return generic_WebL.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
    public boolean clearTextBox(By by) {
        try {
            Thread.sleep(2000);
            WebElement generic_WebL = (new WebDriverWait(driver, 30))
                    .until(ExpectedConditions.visibilityOfElementLocated(by));
            clickByJS(by);
            //generic_WebL.click();
            generic_WebL.clear();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean clearTextBoxUsingBackSpaceKey(By by) {
        try {
            Thread.sleep(2000);
            driver.findElement(by).sendKeys(Keys.chord(Keys.CONTROL, "a"));
            driver.findElement(by).sendKeys(Keys.BACK_SPACE);
            return true;
        } catch (Exception e) {
            return false;
        }
    }



  public String getCurrentDateTime() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMdd_HHmm");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }
    public static String getRandomNumber() {
        // It will generate 9 digit random Number.
        // from 0 to 999999999
        Random rnd = new Random();
        int number = rnd.nextInt(999999999);

        // this will convert any number sequence into 6 character.
        return String.format("%06d", number);
    }


  public static String getRandomString() {
        String generatedString = RandomStringUtils.randomAlphabetic(6);
        //System.out.println(generatedString);
        return generatedString;
    }
}
