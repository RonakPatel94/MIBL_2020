package BasePage;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.aventstack.extentreports.MediaEntityBuilder.createScreenCaptureFromPath;

public class BaseClass {
    public static ExtentHtmlReporter htmlReporter;

    public static ExtentReports extent;

    public static ExtentTest testLogger;//used for add/update test status in report
    public static ExtentTest test; //used for add/update test status in report
    @BeforeSuite
    public void Initialization() throws IOException {
        FileUtils.deleteDirectory(new File(System.getProperty("user.dir") + "\\Report"));
        htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "\\Report\\Report.html");
        //Creating html report
        //htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "\\Reports\\ExtentReport.html");
        //Initializing extent report class object
        extent = new ExtentReports();
        //Attaching html report to Extent report
        extent.attachReporter(htmlReporter);
        htmlReporter.config().setDocumentTitle("Automation Testing"); //Title of report
        htmlReporter.config().setReportName("Testing Report For MIBL"); //Name of report
        htmlReporter.config().setTheme(Theme.STANDARD); //set report theme
        String css = ".r-img {width: 50%;}"; //set width for failure image
        htmlReporter.config().setCSS(css);
        htmlReporter.config().setAutoCreateRelativePathMedia(true);

        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("HostName", "MIBL");
        extent.setSystemInfo("OS", "Windows");
        extent.setSystemInfo("Browser Name", "Chrome");
        extent.setSystemInfo("Tester", "Ronak Patel");
    }

    public WebDriver driver;

    //Headless Browser execution code
  /* @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("headless");
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("https://v2.mibinsure.com/NewHome");
        testLogger = extent.createTest("Headless Browser Execution", "This is Headless Browser Execution");
        //testLogger.log(Status.PASS, "This is Headless Browser Execution");
    }*/

   @BeforeMethod
    @Parameters({"browserName"})
    public void setUp(String browserName) {
        if (browserName.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
           // driver.manage().deleteAllCookies();
            //driver.get("chrome://settings/clearBrowserData");
            //driver.findElement(By.xpath("//settings-ui")).sendKeys(Keys.ENTER);
            driver.get("https://v2.mibinsure.com/NewHome");
        } else if (browserName.equalsIgnoreCase("firefox")) {
            System.setProperty("webdriver.gecko.driver", "src/main/resources/geckodriver.exe");
            driver = new FirefoxDriver();
            driver.manage().window().maximize();
            driver.get("https://v2.mibinsure.com/NewHome");
        }
    }

    @AfterMethod
    public void tearDown(ITestResult result) throws IOException {
        if (result.getStatus() == ITestResult.FAILURE) {
            testLogger.log(Status.FAIL,
                    MarkupHelper.createLabel(result.getName() + " - Test Case FAILED", ExtentColor.RED));
            //testLogger.log(Status.FAIL, result.getName() + " Test Case Failed"); //Get name of test case
            testLogger.log(Status.FAIL, "Failed Test Case Error: " + result.getThrowable()); //add error in report

            MediaEntityModelProvider screenshot = createScreenCaptureFromPath(getScreenshot(driver, result.getMethod().getMethodName())).build();
            testLogger.log(Status.FAIL, "Screenshot", screenshot);
        } else if (result.getStatus() == ITestResult.SKIP) {
            testLogger.log(Status.SKIP,
                    MarkupHelper.createLabel(result.getName() + " - Test Case SKIPPED", ExtentColor.YELLOW));
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            testLogger.log(Status.PASS,
                    MarkupHelper.createLabel(result.getName() + " - Test Case PASSED", ExtentColor.GREEN));

        }

        //driver.quit();

    }

    private static String getScreenshot(WebDriver driver, String screenShotName) throws IOException {
        String currentDate = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
        TakesScreenshot screenshot = (TakesScreenshot) driver;
        File source = screenshot.getScreenshotAs(OutputType.FILE);

        String destination = System.getProperty("user.dir") + "\\Report\\failureImages\\" + screenShotName + "_" + currentDate + ".png";
        File fileDestination = new File(destination);
        FileUtils.copyFile(source, fileDestination);
        System.out.println("Image Path: " + destination);
        return destination;
    }

    @AfterSuite
    public void WindUp() {
        extent.flush();
    }
}
