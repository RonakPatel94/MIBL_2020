package Referordecline_TS;

import BasePage.BaseClass;
import Common.CommonMethods;
import Common.Retry;
import QuickQuote_FourWheeler.QuickQuote_FourWheeler_Page;
import Referordecline.Referordecline_Page;
import Utility.ReadPropertiesFileData;
import com.aventstack.extentreports.Status;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Referordecline_Test extends BaseClass {
    public java.util.Properties prop = null;
    ReadPropertiesFileData readPropertiesFileData = new ReadPropertiesFileData();

    public Referordecline_Test() {
        readPropertiesFileData.readPropertiesFile();
    }


    //@Parameters({"invocationCount"})
    //@Test(retryAnalyzer=Retry.class)
    @Test(invocationCount=1,retryAnalyzer= Retry.class)
    public void Referordecline() throws InterruptedException {
        Referordecline_Page Referordecline = new Referordecline_Page();

        CommonMethods commonMethods = new CommonMethods(driver);
        testLogger = extent.createTest("Refer/decline", "Refer/decline for FourWheeler");
        testLogger.assignCategory("Refer/decline Module");
        testLogger.log(Status.INFO, "MIBL TestCase Started");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnQuickQuote), "Unable to Click on QuickQuote");
        testLogger.log(Status.PASS, "Click on QuickQuote");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnparish), "Unable to Click on Parish");
        testLogger.log(Status.PASS, "Click on Parish");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.Kingstonlive), "Unable to Click on Kingstonlive");
        testLogger.log(Status.PASS, "Click on Kingstonlive");

        Thread.sleep(3000);
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnselectvehicle), "Unable to Click on selectvehicle");
        testLogger.log(Status.PASS, "Click on selectvehicle");

        //Step 5: Click on Continue
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btncontinue), "Unable to Click on continue");
        testLogger.log(Status.PASS, "Click on continue");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnmanufactureyear), "Unable to Click on manufactureyear");
        testLogger.log(Status.PASS, "Click on manufactureyear");

        //Step 22: Vehiclevalue
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.btnclickcar, readPropertiesFileData.getPropertyValue("caryear")), "Unable to Insert caryear");
        testLogger.log(Status.PASS, "Click on caryear");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.inputmanufacturedyear), "Unable to Click on manufacturedyear");
        testLogger.log(Status.PASS, "Click on manufacturedyear");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnvehiclemaker), "Unable to Click on vehiclemaker");
        testLogger.log(Status.PASS, "Click on vehiclemaker");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.carbrandname), "Unable to Click on carbrandname");
        testLogger.log(Status.PASS, "Click on carbrandname");


        Assert.assertTrue(commonMethods.clickByJS(Referordecline.vehiclevehicleModel), "Unable to Click on vehiclevehicleModel");
        testLogger.log(Status.PASS, "Click on vehiclevehicleModel");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.modelofcar), "Unable to Click on modelofcar");
        testLogger.log(Status.PASS, "Click on modelofcar");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.cartype), "Unable to Click on cartype");
        testLogger.log(Status.PASS, "Click on cartype");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnprimaryuse), "Unable to Click on primaryuse");
        testLogger.log(Status.PASS, "Click on primaryuse");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btndistancetravel), "Unable to Click on distancetravel");
        testLogger.log(Status.PASS, "Click on distancetravel");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btncurrentstatumotorcyclepayment), "Unable to Click on currentstatumotorcyclepayment");
        testLogger.log(Status.PASS, "Click on currentstatumotorcyclepayment");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btntypeofcover), "Unable to Click on typeofcover");
        testLogger.log(Status.PASS, "Click on typeofcover");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnComprehensive), "Unable to Click on Comprehensive");
        testLogger.log(Status.PASS, "Click on Comprehensive");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnmotorcycleownedcompny), "Unable to Click on motorcycleownedcompny");
        testLogger.log(Status.PASS, "Click on motorcycleownedcompny");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.btncompanyname, readPropertiesFileData.getPropertyValue("companyname")), "Unable to Insert companyname");
        testLogger.log(Status.PASS, "Click on companyname");


        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnvehiclePurchased), "Unable to Click on vehiclePurchased");
        testLogger.log(Status.PASS, "Click on vehiclePurchased");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnvehicalnewuser), "Unable to Click on vehicalnewuser");
        testLogger.log(Status.PASS, "Click on vehicalnewuser");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.carlefthand), "Unable to Click on carlefthand");
        testLogger.log(Status.PASS, "Click on carlefthand");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.Manual), "Unable to Click on Manual");
        testLogger.log(Status.PASS, "Click on Manual");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnvehicleImported), "Unable to Click on vehicleImported");
        testLogger.log(Status.PASS, "Click on vehicleImported");
       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnvehicleimportedvalue), "Unable to Click on vehicleimportedvalue");
        testLogger.log(Status.PASS, "Click on vehicleimportedvalue");*/
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnIsImportedWithSalvageCertificate), "Unable to Click on Is ImportedWith SalvageCertificate");
        testLogger.log(Status.PASS, "Click on IsImportedWithSalvageCertificate");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.carseatsize), "Unable to Click on carseatsize");
        testLogger.log(Status.PASS, "Click on carseatsize");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btncolorID), "Unable to Click on colorID");
        testLogger.log(Status.PASS, "Click on colorID");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnValuationProformainvoice), "Unable to Click on ValuationProformainvoice");
        testLogger.log(Status.PASS, "Click on btnValuationProformainvoice");
        //Step 22: Vehiclevalue
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.btnvehicleValue, readPropertiesFileData.getPropertyValue("referCarVehiclevalue")), "Unable to Insert referCarVehiclevalue");
        testLogger.log(Status.PASS, "Click on referCarVehiclevalue");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnVehicleModified), "Unable to Click on VehicleModified");
        testLogger.log(Status.PASS, "Click on VehicleModified");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnsecuredOvernightDiv), "Unable to Click on securedOvernight");
        testLogger.log(Status.PASS, "Click on securedOvernight");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnvehicleSometimesUsedAsTrailer), "Unable to Click on vehicleSometimesUsedAsTrailer");
        testLogger.log(Status.PASS, "Click on btnvehicleSometimesUsedAsTrailer");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnRoadworthyAndGoodCondition), "Unable to Click on RoadworthyAndGoodCondition");
        testLogger.log(Status.PASS, "Click on RoadworthyAndGoodCondition");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnisMileageInKm), "Unable to Click on MileageInKm");
        testLogger.log(Status.PASS, "Click on MileageInKm");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.btnmileageDivId, readPropertiesFileData.getPropertyValue("carmilage")), "Unable to Insert mileage");
        testLogger.log(Status.PASS, "Click on car mileage");


        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnenginecctype), "Unable to Click on enginecctype");
        testLogger.log(Status.PASS, "Click on enginecctype");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.dropEnginecc), "Unable to Click on dropEnginecc");
        testLogger.log(Status.PASS, "Click on dropEnginecc");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.Caraccessories), "Unable to Click on Caraccessories");
        testLogger.log(Status.PASS, "Click on Caraccessories");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.trackingdevice), "Unable to Click on trackingdevice");
        testLogger.log(Status.PASS, "Click on trackingdevice");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnsoleOwner), "Unable to Click on soleOwner");
        testLogger.log(Status.PASS, "Click on soleOwner");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.inputfirstname, readPropertiesFileData.getPropertyValue("Firstname") + commonMethods.getRandomString()), "Unable to Insert Firstname");
        testLogger.log(Status.PASS, "Click on Firstname");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.inputmiddlename, readPropertiesFileData.getPropertyValue("Middlename") + commonMethods.getRandomString()), "Unable to Insert Middlename");
        testLogger.log(Status.PASS, "Click on Middlename");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.inputlastname, readPropertiesFileData.getPropertyValue("Lastname") + commonMethods.getRandomString()), "Unable to Insert Lastname");
        testLogger.log(Status.PASS, "Click on Lastname");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btntitle), "Unable to Click on title");
        testLogger.log(Status.PASS, "Click on title");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.Gender), "Unable to Click on Gender");
        testLogger.log(Status.PASS, "Click on Gender");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.Dateofbirth, readPropertiesFileData.getPropertyValue("Dateofbirth")), "Unable to Insert Dateofbirth");
        testLogger.log(Status.PASS, "Click on Dateofbirth");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.maritalstatus), "Unable to Click on maritalstatus");
        testLogger.log(Status.PASS, "Click on maritalstatus");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.maritalstatus1), "Unable to Click on maritalstatus1");
        testLogger.log(Status.PASS, "Click on maritalstatus1");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnvalidprovisional), "Unable to Click on validprovisional");
        testLogger.log(Status.PASS, "Click on validprovisional");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.drpissueDateOfProvisionalLicense, readPropertiesFileData.getPropertyValue("yearprovisional")), "Unable to Insert yearprovisional");
        testLogger.log(Status.PASS, "Click on yearprovisional");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.country), "Unable to Click on country");
        testLogger.log(Status.PASS, "Click on country");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.country1), "Unable to Click on country1");
        testLogger.log(Status.PASS, "Click on country1");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.presentlyemployed), "Unable to Click on presentlyemployed");
        testLogger.log(Status.PASS, "Click on presentlyemployed");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.workindustry), "Unable to Click on workindustry");
        testLogger.log(Status.PASS, "Click on workindustry");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.mainoccupation), "Unable to Click on mainoccupation");
        testLogger.log(Status.PASS, "Click on mainoccupation");
        /*Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.mainoccupation, readPropertiesFileData.getPropertyValue("mainoccupation")), "Unable to Insert mainoccupation");
        testLogger.log(Status.PASS, "Click on mainoccupation");*/


        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btncredit), "Unable to Click on btncredit");
        testLogger.log(Status.PASS, "Click on btncredit");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btneducation), "Unable to Click on btneducation");
        testLogger.log(Status.PASS, "Click on btneducation");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnmotorinsurancepolicy), "Unable to Click on btnmotorinsurancepolicy");
        testLogger.log(Status.PASS, "Click on btnmotorinsurancepolicy");
        /*Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btninsurancecompany), "Unable to Click on btninsurancecompany");
        testLogger.log(Status.PASS, "Click on btninsurancecompany");*/
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnvehicles), "Unable to Click on btnvehicles");
        testLogger.log(Status.PASS, "Click on btnvehicles");
       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.controlcustody), "Unable to Click on controlcustody");
        testLogger.log(Status.PASS, "Click on controlcustody");*/
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.inputemailaddress, readPropertiesFileData.getPropertyValue("emailaddress")), "Unable to Insert emailaddress");
        testLogger.log(Status.PASS, "Click on emailaddress");

        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btntravelwithbaby), "Unable to Click on btntravelwithbaby");
        testLogger.log(Status.PASS, "Click on btntravelwithbaby");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnages), "Unable to Click on btnages");
        testLogger.log(Status.PASS, "Click on btnages");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnmedically), "Unable to Click on btnmedically");
        testLogger.log(Status.PASS, "Click on btnmedically");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnmedically1), "Unable to Click on btnmedically1");
        testLogger.log(Status.PASS, "Click on btnmedically1");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnaccidentclaim), "Unable to Click on btnaccidentclaim");
        testLogger.log(Status.PASS, "Click on btnaccidentclaim");

     /*   Assert.assertTrue(commonMethods.clickByJS(Referordecline.anotherdriver), "Unable to Click on anotherdriver");
        testLogger.log(Status.PASS, "Click on anotherdriver");*/
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btndrivinghistory), "Unable to Click on btndrivinghistory");
        testLogger.log(Status.PASS, "Click on btndrivinghistory");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnprosecuted), "Unable to Click on btnprosecuted");
        testLogger.log(Status.PASS, "Click on btnprosecuted");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnapplicationdeclined), "Unable to Click on btnapplicationdeclined");
        testLogger.log(Status.PASS, "Click on btnapplicationdeclined");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnexcessincreased), "Unable to Click on btnexcessincreased");
        testLogger.log(Status.PASS, "Click on btnexcessincreased");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btncancelledorrenewal), "Unable to Click on btncancelledorrenewal");
        testLogger.log(Status.PASS, "Click on btncancelledorrenewal");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.Anyperiod), "Unable to Click on Anyperiod");
        testLogger.log(Status.PASS, "Click on Anyperiod");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btninfo), "Unable to Click on btninfo");
        testLogger.log(Status.PASS, "Click on btninfo");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnspecialdiscount), "Unable to Click on btnspecialdiscount");
        testLogger.log(Status.PASS, "Click on btnspecialdiscount");
/*        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnNonCommissioned), "Unable to Click on btnNonCommissioned");
        testLogger.log(Status.PASS, "Click on btnNonCommissioned");*/
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btncamerainstalled), "Unable to Click on btncamerainstalled");
        testLogger.log(Status.PASS, "Click on btncamerainstalled");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnfulltimegovernmentemployee), "Unable to Click on btnfulltimegovernmentemployee");
        testLogger.log(Status.PASS, "Click on btnfulltimegovernmentemployee");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnhomeownerpolicy), "Unable to Click on btnhomeownerpolicy");
        testLogger.log(Status.PASS, "Click on btnhomeownerpolicy");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btninsurerwithpolicy), "Unable to Click on btninsurerwithpolicy");
        testLogger.log(Status.PASS, "Click on btninsurerwithpolicy");
        /*Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btninsurerwithpolicy), "Unable to Click on btninsurerwithpolicy");
        testLogger.log(Status.PASS, "Click on btninsurerwithpolicy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnyearshomeownerpolicy), "Unable to Click on btnyearshomeownerpolicy");
        testLogger.log(Status.PASS, "Click on btnyearshomeownerpolicy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnbuyhomeownerpolicy), "Unable to Click on btnbuyhomeownerpolicy");
        testLogger.log(Status.PASS, "Click on btnbuyhomeownerpolicy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(Referordecline.btnIsthisvehiclecurrentlyinsured), "Unable to Click on btnIsthisvehiclecurrentlyinsured");
        testLogger.log(Status.PASS, "Click on btnIsthisvehiclecurrentlyinsured");*/


        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnpolicytostart), "Unable to Click on btnpolicytostart");
        testLogger.log(Status.PASS, "Click on btnpolicytostart");
        Assert.assertTrue(commonMethods.enterTextInInputField(Referordecline.btnPolicyStartDate, readPropertiesFileData.getPropertyValue("PolicyStartDate")), "Unable to Insert PolicyStartDate");
        testLogger.log(Status.PASS, "Click on PolicyStartDate");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnNCD), "Unable to Click on NCD");
        testLogger.log(Status.PASS, "Click on NCD");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnNCDtovehicle), "Unable to Click on NCDtovehicle");
        testLogger.log(Status.PASS, "Click on NCDtovehicle");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnanothermotorinsurancepolicy), "Unable to Click on another motor insurance policy");
        testLogger.log(Status.PASS, "Click on another motor insurance policy");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnanyartisticpaint), "Unable to Click on any artistic paint");
        testLogger.log(Status.PASS, "Click on any artistic paint");
        Assert.assertTrue(commonMethods.clickByJS(Referordecline.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Thread.sleep(5000);
    }
}