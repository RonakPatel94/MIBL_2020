package QuickQuote_TwoWheeler_TS;

import BasePage.BaseClass;
import Common.CommonMethods;
import Common.Retry;
import QuickQuote_TwoWheeler.QuickQuoteTwoWheeler_Page;
import Utility.ReadPropertiesFileData;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TwoWheeler_Test extends BaseClass {

    public java.util.Properties prop = null;
    ReadPropertiesFileData readPropertiesFileData = new ReadPropertiesFileData();

    public TwoWheeler_Test() {
        readPropertiesFileData.readPropertiesFile();
    }

    //@Parameters({"invocationCount"})
    //@Test(retryAnalyzer=Retry.class)
    @Test(invocationCount=1,retryAnalyzer=Retry.class)
    public void QuoteTwoWheelerTest() throws InterruptedException {
        QuickQuoteTwoWheeler_Page QuickQuoteTwoWheeler = new QuickQuoteTwoWheeler_Page();

        CommonMethods commonMethods = new CommonMethods(driver);
        testLogger = extent.createTest("QuickQuote TwoWheeler", "QuickQuote For TwoWheeler");
        testLogger.assignCategory("QuickQuote TwoWheeler Module");
        testLogger.log(Status.INFO, "G-Trac TestCase Started");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnQuickQuote), "Unable to Click on QuickQuote");
        testLogger.log(Status.PASS, "Click on QuickQuote");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnparish), "Unable to Click on Parish");
        testLogger.log(Status.PASS, "Click on Parish");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.Kingstonlive0), "Unable to Click on Kingstonlive");
        testLogger.log(Status.PASS, "Click on Kingstonlive");

        Thread.sleep(2000);
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnselectvehicle), "Unable to Click on selectvehicle");
        testLogger.log(Status.PASS, "Click on selectvehicle");

        //Step 5: Click on Continue
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncontinue), "Unable to Click on continue");
        testLogger.log(Status.PASS, "Click on continue");

        //Step 6: Click on manufactureyear
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmanufactureyear), "Unable to Click on manufactureyear");
        testLogger.log(Status.PASS, "Click on manufactureyear");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.inputmanufacturedyear), "Unable to insert input manufactured year");
        testLogger.log(Status.PASS, "Click on input manufactured year");

        //Step 7: select vehicle maker
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnvehiclemaker), "Unable to Click on vehiclemaker");
        testLogger.log(Status.PASS, "Click on vehicle maker");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.inputvehiclemaker), "Unable to insert input vehicle maker");
        testLogger.log(Status.PASS, "Click on vehicle maker");

        //Step 8: select vehicle model
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnvehiclemodel), "Unable to Click on vehicle model");
        testLogger.log(Status.PASS, "Click on vehicle model");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.inputvehiclemodel), "Unable to insert input vehicle model");
        testLogger.log(Status.PASS, "insert vehicle model");
        //System.out.println("insert vehicle model");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnprimaryuse), "Unable to Click on primary use");
        testLogger.log(Status.PASS, "Click on primary use");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btndistancetravel), "Unable to Click on primary use");
        testLogger.log(Status.PASS, "Click on distancetravel");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncurrentstatumotorcyclepayment), "Unable to click current status motorcycle payment");
        testLogger.log(Status.PASS, "Click on current status motorcycle payment");

        //Step 10: typeofcover
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btntypeofcover), "Unable to Click on typeofcover");
        testLogger.log(Status.PASS, "Click on typeofcover");

        //Step 11: comprehensive
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnComprehensive), "Unable to Click on comprehensive");
        testLogger.log(Status.PASS, "Click on comprehensive");

        //Step 12: motorcycleownedcompny
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.motorcycleownedbyacompany), "Unable to Click on motorcycle owned company");
        testLogger.log(Status.PASS, "Click on motorcycle owned company");

        //Step 13: motorcycle just purchased this motorcycle
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.justpurchasedthismotorcycle), "Unable to Click on just purchased this motorcycle");
        testLogger.log(Status.PASS, "Click on motorcycle just purchased");

        //Step 14: motorcycle new or used
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.motorcycleneworused), "Unable to Click on motorcycle new or used");
        testLogger.log(Status.PASS, "Click on motorcycle new or used");

        //Step 17: vehicleImported
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.importthismotorcycle), "Unable to Click on vehicle Imported");
        testLogger.log(Status.PASS, "Click on vehicle Imported");

        //Step 19: ImportedWithSalvageCertificate
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.salvagecertificate), "Unable to Click on Imported With SalvageCertificate");
        testLogger.log(Status.PASS, "Click on Imported With SalvageCertificate");

        //Step 20: btncolorID
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.colourmotorcycle), "Unable to Click on btncolorID");
        testLogger.log(Status.PASS, "Click on btncolorID");
        //Step 21: ValuationProformainvoice
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.valuationproformainvoice), "Unable to Click on Valuation Performance invoice");
        testLogger.log(Status.PASS, "Click on Valuation Performance invoice");

        //Step 22: Vehiclevalue
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.btnvehicleValue, readPropertiesFileData.getPropertyValue("Vehiclevalue")), "Unable to Insert Vehiclevalue");
        testLogger.log(Status.PASS, "Click on Vehiclevalue");

        //Step 23: VehicleModified
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnVehicleModified), "Unable to Click on VehicleModified");
        testLogger.log(Status.PASS, "Click on VehicleModified");

        //Step 24: securedOvernightDiv
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnsecuredOvernightDiv), "Unable to Click on SecuredOvernightDiv");
        testLogger.log(Status.PASS, "Click on SecuredOvernightDiv");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnvehicleSometimesUsedAsTrailer), "Unable to Click on btnvehicleSometimesUsedAsTrailer");
        testLogger.log(Status.PASS, "Click on btnvehicleSometimesUsedAsTrailer");

        //Step 26: RoadworthyAndGoodCondition
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnRoadworthyAndGoodCondition), "Unable to Click on Road worthy And GoodCondition");
        testLogger.log(Status.PASS, "Click on Road worthy And GoodCondition");

        //Step 27: btnisMileageInKm
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnisMileageInKm), "Unable to Click on Mileage In Km");
        testLogger.log(Status.PASS, "Click on Mileage In Km");

        //Step 28: btnmileageDivId
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.btnmileageDivId, readPropertiesFileData.getPropertyValue("mileage")), "Unable to Insert btnmileageDivId");
        testLogger.log(Status.PASS, "Click on mileageDivId");

        //Step 29: enginecapacity
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnenginecctype), "Unable to Click on Engine cc-type");
        testLogger.log(Status.PASS, "Click on Engine cc-type");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.dropEnginecc), "Unable to Click on Dropdown Engine cc-type");
        testLogger.log(Status.PASS, "Click on Dropdown Engine cc-type");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextButton");
        testLogger.log(Status.PASS, "Click on NextButton");
        //Step 30: soleOwner
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnsoleOwner), "Unable to Click on soleOwner");
        testLogger.log(Status.PASS, "Click on SoleOwner and User details");


        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputfirstname, readPropertiesFileData.getPropertyValue("Firstname") + commonMethods.getRandomString()), "Unable to Insert Firstname");
        testLogger.log(Status.PASS, "Click on Firstname");
        //System.out.println(readPropertiesFileData.getPropertyValue("Firstname")+ commonMethods.getRandomString());

        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputmiddlename, readPropertiesFileData.getPropertyValue("Middlename") + CommonMethods.getRandomString()), "Unable to Insert Middlename");
        testLogger.log(Status.PASS, "Click on Middlename");
        //System.out.println(readPropertiesFileData.getPropertyValue("Middlename")+ commonMethods.getRandomString());

        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputlastname, readPropertiesFileData.getPropertyValue("Lastname") + CommonMethods.getRandomString()), "Unable to Insert Lastname");
        testLogger.log(Status.PASS, "Click on Lastname");
        //System.out.println(readPropertiesFileData.getPropertyValue("Lastname")+ commonMethods.getRandomString());

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btntitle), "Unable to Click on title");
        testLogger.log(Status.PASS, "Click on title");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.Gender), "Unable to Click on Gender");
        testLogger.log(Status.PASS, "Click on Gender");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.Dateofbirth, readPropertiesFileData.getPropertyValue("Dateofbirth")), "Unable to Insert Date of birth");
        testLogger.log(Status.PASS, "Click on Date of birth");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.maritalstatus), "Unable to Click on marital status");
        testLogger.log(Status.PASS, "Click on marital status");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.maritalstatus1), "Unable to Click on marital status");
        testLogger.log(Status.PASS, "Click on marital status 1");

        //Step 33:validprovisional
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.validprovisionallearnerslicense), "Unable to Click on valid provisional");
        testLogger.log(Status.PASS, "Click on valid provisional");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.possessvaliddriverlicense), "Unable to Click on possess valid driver license");
        testLogger.log(Status.PASS, "Click on possess valid driver license");

        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.driverlicensefirstissued, readPropertiesFileData.getPropertyValue("yearprovisional")), "Unable to Insert yearprovisional");
        testLogger.log(Status.PASS, "Click on  driver license first issued");
        //System.out.println("driver license first issued");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.countryissued), "Unable to Click on country issued");
        testLogger.log(Status.PASS, "Click on country issued");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.countrydrivein), "Unable to Click on country Drivein");
        testLogger.log(Status.PASS, "Click on country Drivein");
        //System.out.println("country");

       /* Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.countryissued), "Unable to Click on country issued");
        testLogger.log(Status.PASS, "Click on country issued");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.countrydrivein), "Unable to Click on country Drivein");
        testLogger.log(Status.PASS, "Click on country Drivein");
        System.out.println("country");*/

    /*    Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on Next Button");
        testLogger.log(Status.PASS, "Click on Next Button");
*/
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.presentlyemployed), "Unable to Click on presentlyemployed");
        testLogger.log(Status.PASS, "Click on Presently employed");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.workindustry), "Unable to Click on work industry");
        testLogger.log(Status.PASS, "Click on work industry");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.Occupation), "Unable to Click on Occupation");
        testLogger.log(Status.PASS, "Click on Occupation");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncredit), "Unable to Click on credit");
        testLogger.log(Status.PASS, "Click on Credit");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btneducation), "Unable to Click on Education");
        testLogger.log(Status.PASS, "Click on Education");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmotorinsurancepolicy), "Unable to Click on Motor Insurance policy");
        testLogger.log(Status.PASS, "Click on Motor Insurance policy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.morethantwovehicles), "Unable to Click on more than two vehicles");
        testLogger.log(Status.PASS, "Click on more than two vehicles");
        //System.out.println("Click on more than two vehicles");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputemailaddress, readPropertiesFileData.getPropertyValue("emailaddress")), "Unable to Insert Email Address");
        testLogger.log(Status.PASS, "Click on Email Address");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.travelwithbaby), "Unable to Click on Travel with baby");
        testLogger.log(Status.PASS, "Click on Travel with baby");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmedically), "Unable to Click on Medically");
        testLogger.log(Status.PASS, "Click on Medically");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmedically1), "Unable to Click on Medically Button");
        testLogger.log(Status.PASS, "Click on Medically Button");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on Next Button");
        testLogger.log(Status.PASS, "Click on Next Button");

        //co owner
        Thread.sleep(2000);
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.addinputfirstname, readPropertiesFileData.getPropertyValue("Firstname") + commonMethods.getRandomString()), "Unable to Insert Firstname");
        testLogger.log(Status.PASS, "Click on Firstname");
        //System.out.println(readPropertiesFileData.getPropertyValue("Firstname")+ commonMethods.getRandomString());

        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.addinputmiddlename, readPropertiesFileData.getPropertyValue("Middlename") + CommonMethods.getRandomString()), "Unable to Insert Middlename");
        testLogger.log(Status.PASS, "Click on Middlename");
        //System.out.println(readPropertiesFileData.getPropertyValue("Middlename")+ commonMethods.getRandomString());

        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.addinputlastname, readPropertiesFileData.getPropertyValue("Lastname") + CommonMethods.getRandomString()), "Unable to Insert Lastname");
        testLogger.log(Status.PASS, "Click on Lastname");
        //System.out.println(readPropertiesFileData.getPropertyValue("Lastname")+ commonMethods.getRandomString());
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.addinputfirstname, readPropertiesFileData.getPropertyValue("Firstname") + commonMethods.getRandomString()), "Unable to Insert Firstname");
        testLogger.log(Status.PASS, "Click on Firstname");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addbtntitle), "Unable to Click on title");
        testLogger.log(Status.PASS, "Click on Mr");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addGender), "Unable to Click on Gender");
        testLogger.log(Status.PASS, "Click on Gender");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.addDateofbirth, readPropertiesFileData.getPropertyValue("Dateofbirth")), "Unable to Insert Date of birth");
        testLogger.log(Status.PASS, "Click on Date of birth");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.maritalstatus), "Unable to Click on marital status");
        testLogger.log(Status.PASS, "Click on marital status");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.maritalstatus1), "Unable to Click on marital status");
        testLogger.log(Status.PASS, "Click on marital status 1");
        //Step 33:validprovisional
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addProvisionalLicenseInsured), "Unable to Click on valid provisional");
        testLogger.log(Status.PASS, "Click on valid provisional");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addpossess), "Unable to Click on possess");
        testLogger.log(Status.PASS, "Click on valid possess");

       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.possessvaliddriverlicense), "Unable to Click on possess valid driver license");
        testLogger.log(Status.PASS, "Click on possess valid driver license");*/

        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.adddriverlicensefirstissued, readPropertiesFileData.getPropertyValue("yearprovisional")), "Unable to Insert yearprovisional");
        testLogger.log(Status.PASS, "Click on  driver license first issued");
        //System.out.println("driver license first issued");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addcountryissued), "Unable to Click on country issued");
        testLogger.log(Status.PASS, "Click on country issued");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addcountrydrivein), "Unable to Click on country Drivein");
        testLogger.log(Status.PASS, "Click on country Drivein");
        //System.out.println("country");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.presentlyemployed), "Unable to Click on presentlyemployed");
        testLogger.log(Status.PASS, "Click on Presently employed");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.workindustry), "Unable to Click on work industry");
        testLogger.log(Status.PASS, "Click on work industry");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.Occupation), "Unable to Click on Occupation");
        testLogger.log(Status.PASS, "Click on Occupation");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncredit), "Unable to Click on credit");
        testLogger.log(Status.PASS, "Click on Credit");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addbtneducation), "Unable to Click on Education");
        testLogger.log(Status.PASS, "Click on Education");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmotorinsurancepolicy), "Unable to Click on Motor Insurance policy");
        testLogger.log(Status.PASS, "Click on Motor Insurance policy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.morethantwovehicles), "Unable to Click on more than two vehicles");
        testLogger.log(Status.PASS, "Click on more than two vehicles");
        //System.out.println("Click on more than two vehicles");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.GatedCommunity), "Unable to Click on GatedCommunity");
        testLogger.log(Status.PASS, "Click on GatedCommunity");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputemailaddress, readPropertiesFileData.getPropertyValue("emailaddress")), "Unable to Insert Email Address");
        testLogger.log(Status.PASS, "Click on Email Address");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.travelwithbaby), "Unable to Click on Travel with baby");
        testLogger.log(Status.PASS, "Click on Travel with baby");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmedically), "Unable to Click on Medically");
        testLogger.log(Status.PASS, "Click on Medically");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmedically1), "Unable to Click on Medically Button");
        testLogger.log(Status.PASS, "Click on Medically Button");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");

        Thread.sleep(2000);
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnaccidentclaim), "Unable to Click on Accident Claim");
        testLogger.log(Status.PASS, "Click on Accident claim");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.receivedaticket), "Unable to Click on receivedaticket");
        testLogger.log(Status.PASS, "Click on receivedaticket");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnprosecuted), "Unable to Click on Prosecuted");
        testLogger.log(Status.PASS, "Click on Prosecuted");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnapplicationdeclined), "Unable to Click on Application declined");
        testLogger.log(Status.PASS, "Click on Application declined");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnexcessincreased), "Unable to Click on Excess increased");
        testLogger.log(Status.PASS, "Click on Excess increased");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncancelledorrenewal), "Unable to Click on Cancelled or renewal");
        testLogger.log(Status.PASS, "Click on Cancelled or renewal");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnconsecutiveperiod), "Unable to Click on Consecutive Period");
        testLogger.log(Status.PASS, "Click on Consecutive Period");

        ////Add's claim history
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.claimbtnaccidentclaim), "Unable to Click on claimbtnaccidentclaim");
        testLogger.log(Status.PASS, "Click on claimbtnaccidentclaim");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.claimreceivedaticket), "Unable to Click on claimreceivedaticket");
        testLogger.log(Status.PASS, "Click on claimreceivedaticket");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.claimbtnprosecuted), "Unable to Click on claimbtnprosecuted");
        testLogger.log(Status.PASS, "Click on claimbtnprosecuted");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.claimbtnapplicationdeclined), "Unable to Click on claimbtnapplicationdeclined");
        testLogger.log(Status.PASS, "Click on claimbtnapplicationdeclined");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.claimbtnexcessincreased), "Unable to Click on claimbtnexcessincreased");
        testLogger.log(Status.PASS, "Click on claimbtnexcessincreased");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.claimbtncancelledorrenewal), "Unable to Click on claimbtncancelledorrenewal");
        testLogger.log(Status.PASS, "Click on claimbtncancelledorrenewal");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.claimbtnconsecutiveperiod), "Unable to Click on claimbtnconsecutiveperiod");
        testLogger.log(Status.PASS, "Click on claimbtnconsecutiveperiod");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btninfo), "Unable to Click on Info Button");
        testLogger.log(Status.PASS, "Click on Info Button");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");
        //System.out.println("co-owner");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.addbtnspecialdiscount), "Unable to Click on specialdiscount");
        testLogger.log(Status.PASS, "Click on specialdiscount");
        //Step 41:Camera installed
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncamerainstalled), "Unable to Click on Camera installed");
        testLogger.log(Status.PASS, "Click on Camera installed");

        //Step 42:fulltime government employee
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnfulltimegovernmentemployee), "Unable to Click on Fulltime government employee");
        testLogger.log(Status.PASS, "Click on fulltime government employee");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnhomeownerpolicy), "Unable to Click on home owner policy");
        testLogger.log(Status.PASS, "Click on Home owner Policy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.currentlyinsured), "Unable to Click on currentlyinsured");
        testLogger.log(Status.PASS, "Click on currentlyinsured");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.policytostart), "Unable to Click on policytostart");
        testLogger.log(Status.PASS, "Click on policytostart");

       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.NCD), "Unable to Click on NCD");
        testLogger.log(Status.PASS, "Click on NCD");*/
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.NCD1), "Unable to Click on NCD");
        testLogger.log(Status.PASS, "Click on NCD");

        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");
        Thread.sleep(2000);
      /*  Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.NCDtothisvehicle), "Unable to Click on NCDtothisvehicle");
        testLogger.log(Status.PASS, "Click on NCDtothisvehicle");*/


        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.NCDtothisvehicle), "Unable to Click on NCDtothisvehicle");
        testLogger.log(Status.PASS, "Click on NCDtothisvehicle");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.motorinsurancepolicy), "Unable to Click on motorinsurancepolicy");
        testLogger.log(Status.PASS, "Click on motorinsurancepolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.artisticpaintfinishes), "Unable to Click on artisticpaintfinishes");
        testLogger.log(Status.PASS, "Click on artisticpaintfinishes");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnspecialdisc), "Unable to Click on btnspecialdiscount");
        testLogger.log(Status.PASS, "Click on specialdiscount");

     /*   Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.Insuredspecialdiscount), "Unable to Click on Insuredspecialdiscount");
        testLogger.log(Status.PASS, "Click on Insuredspecialdiscount");*/
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.fulltimegovernmentemployee), "Unable to Click on fulltimegovernmentemployee");
        testLogger.log(Status.PASS, "Click on fulltimegovernmentemployee");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.homeownerpolicy), "Unable to Click on homeownerpolicy");
        testLogger.log(Status.PASS, "Click on homeownerpolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.insuredmotorinsurancepolicy), "Unable to Click on insuredmotorinsurancepolicy");
        testLogger.log(Status.PASS, "Click on insuredmotorinsurancepolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.NoClaimsDiscountNCD), "Unable to Click on NoClaimsDiscountNCD");
        testLogger.log(Status.PASS, "Click on NoClaimsDiscountNCD");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");

        List<WebElement> clomVal = driver.findElements(QuickQuoteTwoWheeler.txtcarrier);
        for (int i = 0; i < clomVal.size(); i++) {
            //testLogger.log(Status.PASS,"The Value is :\n" + clomVal.get(i).getText());
            //System.out.println("the Value is :\n " + clomVal.get(i).getText());
            if (clomVal.get(i).equals("Your Lowest Quote")) {
                clomVal.get(i).click();
            }
            break;
        }
        //Step 45:showquote
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnshowquote), "Unable to Click on Show Quote");
        testLogger.log(Status.PASS, "Click on Show Quote");

   /*  //Step 46:Quotecompare
        List<WebElement> myList = driver.findElements(By.xpath("//h4[@class='text-primary d-inline-block border-top border-bottom border-yellow pb-1 ng-binding']"));
        //To store all web elements into list
        List<String> all_elements_text = new ArrayList<String>();
        for (int i = 0; i < myList.size(); i++) {
            all_elements_text.add(myList.get(i).getText());
            //System.out.println(myList.get(i).getText());
        }
        Object objmin = Collections.min(all_elements_text);
        Object objmax = Collections.max(all_elements_text);

        //System.out.println("The Lowest value :" + objmin);
        //System.out.println("The Highest value :" + objmax);
        if (objmin == objmax) {
            testLogger.log(Status.PASS, "The Lowest value :" + objmin);
            testLogger.log(Status.PASS, "The Highest value :" + objmax);
        } else {
            Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.lowestbuyvalue), "Unable to Click on Lowest Buy Value");
            testLogger.log(Status.PASS, "Click on Lowest Buy Value is :-" + objmin);
        }
*/
        //Step 47: Close Associate Holding
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.lowestbuyvalue), "Unable to Click on Lowest Buy Value");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputTRN, readPropertiesFileData.getPropertyValue("TRN") + commonMethods.getRandomNumber()), "Unable to Insert TRN");
        testLogger.log(Status.PASS, "Click on TRN");
        // System.out.println(readPropertiesFileData.getPropertyValue("TRN")+commonMethods.getRandomNumber());
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncloseassociateholding), "Unable to Click on Close Associate Holding");
        testLogger.log(Status.PASS, "Click on Close Associate Holding");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.btnmothermaidenname, readPropertiesFileData.getPropertyValue("Mothername")), "Unable to Insert Mother Name");
        testLogger.log(Status.PASS, "Click on Mother Name");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputaddress, readPropertiesFileData.getPropertyValue("address")), "Unable to Insert address");
        testLogger.log(Status.PASS, "Click on Address");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputstreetnumber, readPropertiesFileData.getPropertyValue("Streetnumber")), "Unable to Insert Street Number");
        testLogger.log(Status.PASS, "Click on Street Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputstreetname, readPropertiesFileData.getPropertyValue("Streetname")), "Unable to Insert Street Name");
        testLogger.log(Status.PASS, "Click on Street Name");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnIsyourmailingaddress), "Unable to Click on Is Your Mailing Address");
        testLogger.log(Status.PASS, "Click on Your Mailing Address");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputcompanyname1, readPropertiesFileData.getPropertyValue("companyname1")), "Unable to Insert companyname1");
        testLogger.log(Status.PASS, "Click on companyname1");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.Kingstonlive1), "Unable to Click on Kingstonlive");
        testLogger.log(Status.PASS, "Click on Kingstonlive");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputmobile, readPropertiesFileData.getPropertyValue("mobilenumber")), "Unable to Insert mobilenumber");
        testLogger.log(Status.PASS, "Click on Mobile Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputwork, readPropertiesFileData.getPropertyValue("Worknumber")), "Unable to Insert Worknumber");
        testLogger.log(Status.PASS, "Click on Worknumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputResidential, readPropertiesFileData.getPropertyValue("Residentialnumber")), "Unable to Insert Residential Number");
        testLogger.log(Status.PASS, "Click on Residential Number");

        Thread.sleep(1000);
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputTRN, readPropertiesFileData.getPropertyValue("coTRN") + commonMethods.getRandomNumber()), "Unable to Insert TRN");
        testLogger.log(Status.PASS, "Click on TRN");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.cobtncloseassociateholding), "Unable to Click on Close Associate Holding");
        testLogger.log(Status.PASS, "Click on Close Associate Holding");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.cobtnmothermaidenname, readPropertiesFileData.getPropertyValue("Mothername")), "Unable to Insert Mother Name");
        testLogger.log(Status.PASS, "Click on Mother Name");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputaddress, readPropertiesFileData.getPropertyValue("address")), "Unable to Insert address");
        testLogger.log(Status.PASS, "Click on Address");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputstreetnumber, readPropertiesFileData.getPropertyValue("Streetnumber1")), "Unable to Insert Street Number");
        testLogger.log(Status.PASS, "Click on Street Number");
        //System.out.println(readPropertiesFileData.getPropertyValue("Streetnumber1"));
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputstreetname, readPropertiesFileData.getPropertyValue("Streetname")), "Unable to Insert Street Name");
        testLogger.log(Status.PASS, "Click on Street Name");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputcompanyname2, readPropertiesFileData.getPropertyValue("companyname2")), "Unable to Insert companyname1");
        testLogger.log(Status.PASS, "Click on companyname1");
       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.cobtnIsyourmailingaddress), "Unable to Click on Is Your Mailing Address");
        testLogger.log(Status.PASS, "Click on Your Mailing Address");
       */

        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.Kingstonlive2), "Unable to Click on Kingstonlive");
        testLogger.log(Status.PASS, "Click on Kingstonlive");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputmobile, readPropertiesFileData.getPropertyValue("mobilenumber")), "Unable to Insert mobilenumber");
        testLogger.log(Status.PASS, "Click on Mobile Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputwork, readPropertiesFileData.getPropertyValue("Worknumber")), "Unable to Insert Worknumber");
        testLogger.log(Status.PASS, "Click on Worknumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputResidential, readPropertiesFileData.getPropertyValue("Residentialnumber")), "Unable to Insert Residential Number");
        testLogger.log(Status.PASS, "Click on Residential Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.registrationnumber, readPropertiesFileData.getPropertyValue("registrationnumber") + CommonMethods.getRandomNumber()), "Unable to Insert Residential Number");
        testLogger.log(Status.PASS, "Click on Residential Number");
        //System.out.println(readPropertiesFileData.getPropertyValue("registrationnumber")+CommonMethods.getRandomNumber());

        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputmotorcycleenginenumber, readPropertiesFileData.getPropertyValue("motorcycleenginenumber")), "Unable to Insert motorcycle engine number");
        testLogger.log(Status.PASS, "Click on motorcycle engine number");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputmotorcycleChassisnumber, readPropertiesFileData.getPropertyValue("motorcycleChassisnumber")), "Unable to Insert Motorcycle Chassis number");
        testLogger.log(Status.PASS, "Click on Motorcycle Chassis Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.coinputstreetnumber, readPropertiesFileData.getPropertyValue("Streetnumber1")), "Unable to Insert Street Number");
        testLogger.log(Status.PASS, "Click on Street Number");
        //System.out.println(readPropertiesFileData.getPropertyValue("Streetnumber1"));
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");

        //Step 48: Pay Your Premiums
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnsalary), "Unable to Click on Salary");
        testLogger.log(Status.PASS, "Click on Salary");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnfullpayment), "Unable to Click on Full Payment");
        testLogger.log(Status.PASS, "Click on Full Payment");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btncreditcard), "Unable to Click on Credit Card");
        testLogger.log(Status.PASS, "Click on Credit Card");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuoteTwoWheeler.btnmastercard), "Unable to Click on mastercard");
        testLogger.log(Status.PASS, "Click on Mastercard");

        //Step 48:Creditcardinformation
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputcardname, readPropertiesFileData.getPropertyValue("cardname")), "Unable to Insert cardname");
        testLogger.log(Status.PASS, "Card Name is :-" + readPropertiesFileData.getPropertyValue("cardname"));
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputcardnumber, readPropertiesFileData.getPropertyValue("cardnumber")), "Unable to Insert cardnumber");
        testLogger.log(Status.PASS, "Card Number is :-" + readPropertiesFileData.getPropertyValue("cardnumber"));
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btndropclickmonth), "Unable to Click on DropDown Month");
        //test.log(Status.PASS, "Click on Month");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.drpcardmonth), "Unable to Click on cardmonth");
        testLogger.log(Status.PASS, "Click on cardmonth");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btndropclick), "Unable to Click on Month");
        testLogger.log(Status.PASS, "Click on Month");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.drpcardyear), "Unable to Click on Year");
        testLogger.log(Status.PASS, "Click on Year");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuoteTwoWheeler.inputsecuritycode, readPropertiesFileData.getPropertyValue("securitycode")), "Unable to Insert cardnumber");
        testLogger.log(Status.PASS, "Security Code is :-" + readPropertiesFileData.getPropertyValue("securitycode"));
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuoteTwoWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");
        Thread.sleep(5000);
        Assert.assertTrue(commonMethods.verifyElementIsVisible(QuickQuoteTwoWheeler.thankyou), "Unable to Click your payment was successful!");
        testLogger.log(Status.PASS, "Your Payment Was Successful!");


    }
}