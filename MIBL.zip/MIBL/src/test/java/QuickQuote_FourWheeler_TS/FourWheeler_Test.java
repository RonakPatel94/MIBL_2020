package QuickQuote_FourWheeler_TS;

import BasePage.BaseClass;
import Common.CommonMethods;
import Common.Retry;
import QuickQuote_FourWheeler.QuickQuote_FourWheeler_Page;
import Utility.ReadPropertiesFileData;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FourWheeler_Test extends BaseClass {
    public java.util.Properties prop = null;
    ReadPropertiesFileData readPropertiesFileData = new ReadPropertiesFileData();

    public FourWheeler_Test() {
        readPropertiesFileData.readPropertiesFile();
    }


    @Parameters({"invocationCount"})
    //@Test(retryAnalyzer=Retry.class)
    @Test(invocationCount=1,retryAnalyzer=Retry.class)
    public void FourWheelerTest() throws InterruptedException {
        QuickQuote_FourWheeler_Page QuickQuotefourWheeler = new QuickQuote_FourWheeler_Page();

        CommonMethods commonMethods = new CommonMethods(driver);
        testLogger = extent.createTest("QuickQuote FourWheeler", "QuickQuote For FourWheeler");
        testLogger.assignCategory("QuickQuote FourWheeler Module");
        testLogger.log(Status.INFO, "G-Trac TestCase Started");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnQuickQuote), "Unable to Click on QuickQuote");
        testLogger.log(Status.PASS, "Click on QuickQuote");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnparish), "Unable to Click on Parish");
        testLogger.log(Status.PASS, "Click on Parish");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.Kingstonlive), "Unable to Click on Kingstonlive");
        testLogger.log(Status.PASS, "Click on Kingstonlive");

        Thread.sleep(3000);
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnselectvehicle), "Unable to Click on selectvehicle");
        testLogger.log(Status.PASS, "Click on selectvehicle");

        //Step 5: Click on Continue
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncontinue), "Unable to Click on continue");
        testLogger.log(Status.PASS, "Click on continue");

        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnmanufactureyear), "Unable to Click on manufactureyear");
        testLogger.log(Status.PASS, "Click on manufactureyear");

        //Step 22: Vehiclevalue
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.btnclickcar, readPropertiesFileData.getPropertyValue("caryear")), "Unable to Insert caryear");
        testLogger.log(Status.PASS, "Click on caryear");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.inputmanufacturedyear), "Unable to Click on manufacturedyear");
        testLogger.log(Status.PASS, "Click on manufacturedyear");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnvehiclemaker), "Unable to Click on vehiclemaker");
        testLogger.log(Status.PASS, "Click on vehiclemaker");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.carbrandname), "Unable to Click on carbrandname");
        testLogger.log(Status.PASS, "Click on carbrandname");

        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.vehiclevehicleModel), "Unable to Click on vehiclevehicleModel");
        testLogger.log(Status.PASS, "Click on vehiclevehicleModel");

        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.modelofcar), "Unable to Click on modelofcar");
        testLogger.log(Status.PASS, "Click on modelofcar");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.cartype), "Unable to Click on cartype");
        testLogger.log(Status.PASS, "Click on cartype");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnprimaryuse), "Unable to Click on primaryuse");
        testLogger.log(Status.PASS, "Click on primaryuse");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btndistancetravel), "Unable to Click on distancetravel");
        testLogger.log(Status.PASS, "Click on distancetravel");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncurrentstatumotorcyclepayment), "Unable to Click on currentstatumotorcyclepayment");
        testLogger.log(Status.PASS, "Click on currentstatumotorcyclepayment");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btntypeofcover), "Unable to Click on typeofcover");
        testLogger.log(Status.PASS, "Click on typeofcover");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnComprehensive), "Unable to Click on Comprehensive");
        testLogger.log(Status.PASS, "Click on Comprehensive");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnmotorcycleownedcompny), "Unable to Click on motorcycleownedcompny");
        testLogger.log(Status.PASS, "Click on motorcycleownedcompny");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnvehiclePurchased), "Unable to Click on vehiclePurchased");
        testLogger.log(Status.PASS, "Click on vehiclePurchased");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnvehicalnewuser), "Unable to Click on vehicalnewuser");
        testLogger.log(Status.PASS, "Click on vehicalnewuser");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.carlefthand), "Unable to Click on carlefthand");
        testLogger.log(Status.PASS, "Click on carlefthand");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.Manual), "Unable to Click on Manual");
        testLogger.log(Status.PASS, "Click on Manual");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnvehicleImported), "Unable to Click on vehicleImported");
        testLogger.log(Status.PASS, "Click on vehicleImported");
       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnvehicleimportedvalue), "Unable to Click on vehicleimportedvalue");
        testLogger.log(Status.PASS, "Click on vehicleimportedvalue");*/
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnIsImportedWithSalvageCertificate), "Unable to Click on Is ImportedWith SalvageCertificate");
        testLogger.log(Status.PASS, "Click on IsImportedWithSalvageCertificate");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.carseatsize), "Unable to Click on carseatsize");
        testLogger.log(Status.PASS, "Click on carseatsize");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncolorID), "Unable to Click on colorID");
        testLogger.log(Status.PASS, "Click on colorID");

        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnValuationProformainvoice), "Unable to Click on ValuationProformainvoice");
        testLogger.log(Status.PASS, "Click on btnValuationProformainvoice");
        //Step 22: Vehiclevalue
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.btnvehicleValue, readPropertiesFileData.getPropertyValue("CarVehiclevalue")), "Unable to Insert CarVehiclevalue");
        testLogger.log(Status.PASS, "Click on CarVehiclevalue");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnVehicleModified), "Unable to Click on VehicleModified");
        testLogger.log(Status.PASS, "Click on VehicleModified");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnsecuredOvernightDiv), "Unable to Click on securedOvernight");
        testLogger.log(Status.PASS, "Click on securedOvernight");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnvehicleSometimesUsedAsTrailer), "Unable to Click on vehicleSometimesUsedAsTrailer");
        testLogger.log(Status.PASS, "Click on btnvehicleSometimesUsedAsTrailer");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnRoadworthyAndGoodCondition), "Unable to Click on RoadworthyAndGoodCondition");
        testLogger.log(Status.PASS, "Click on RoadworthyAndGoodCondition");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnisMileageInKm), "Unable to Click on MileageInKm");
        testLogger.log(Status.PASS, "Click on MileageInKm");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.btnmileageDivId, readPropertiesFileData.getPropertyValue("carmilage")), "Unable to Insert mileage");
        testLogger.log(Status.PASS, "Click on car mileage");


        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnenginecctype), "Unable to Click on enginecctype");
        testLogger.log(Status.PASS, "Click on enginecctype");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.dropEnginecc), "Unable to Click on dropEnginecc");
        testLogger.log(Status.PASS, "Click on dropEnginecc");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.Caraccessories), "Unable to Click on Caraccessories");
        testLogger.log(Status.PASS, "Click on Caraccessories");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.trackingdevice), "Unable to Click on trackingdevice");
        testLogger.log(Status.PASS, "Click on trackingdevice");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnsoleOwner), "Unable to Click on soleOwner");
        testLogger.log(Status.PASS, "Click on soleOwner");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputfirstname, readPropertiesFileData.getPropertyValue("Firstname") + commonMethods.getRandomString()), "Unable to Insert Firstname");
        testLogger.log(Status.PASS, "Click on Firstname");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputmiddlename, readPropertiesFileData.getPropertyValue("Middlename") + commonMethods.getRandomString()), "Unable to Insert Middlename");
        testLogger.log(Status.PASS, "Click on Middlename");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputlastname, readPropertiesFileData.getPropertyValue("Lastname") + commonMethods.getRandomString()), "Unable to Insert Lastname");
        testLogger.log(Status.PASS, "Click on Lastname");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btntitle), "Unable to Click on title");
        testLogger.log(Status.PASS, "Click on title");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.Gender), "Unable to Click on Gender");
        testLogger.log(Status.PASS, "Click on Gender");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.Dateofbirth, readPropertiesFileData.getPropertyValue("Dateofbirth")), "Unable to Insert Dateofbirth");
        testLogger.log(Status.PASS, "Click on Dateofbirth");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.maritalstatus), "Unable to Click on maritalstatus");
        testLogger.log(Status.PASS, "Click on maritalstatus");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.maritalstatus1), "Unable to Click on maritalstatus1");
        testLogger.log(Status.PASS, "Click on maritalstatus1");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnvalidprovisional), "Unable to Click on validprovisional");
        testLogger.log(Status.PASS, "Click on validprovisional");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.drpissueDateOfProvisionalLicense, readPropertiesFileData.getPropertyValue("yearprovisional")), "Unable to Insert yearprovisional");
        testLogger.log(Status.PASS, "Click on yearprovisional");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.country), "Unable to Click on country");
        testLogger.log(Status.PASS, "Click on country");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.country1), "Unable to Click on country1");
        testLogger.log(Status.PASS, "Click on country1");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.presentlyemployed), "Unable to Click on presentlyemployed");
        testLogger.log(Status.PASS, "Click on presentlyemployed");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.workindustry), "Unable to Click on workindustry");
        testLogger.log(Status.PASS, "Click on workindustry");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.mainoccupation), "Unable to Click on mainoccupation");
        testLogger.log(Status.PASS, "Click on mainoccupation");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncredit), "Unable to Click on btncredit");
        testLogger.log(Status.PASS, "Click on btncredit");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btneducation), "Unable to Click on btneducation");
        testLogger.log(Status.PASS, "Click on btneducation");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnmotorinsurancepolicy), "Unable to Click on btnmotorinsurancepolicy");
        testLogger.log(Status.PASS, "Click on btnmotorinsurancepolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btninsurancecompany), "Unable to Click on btninsurancecompany");
        testLogger.log(Status.PASS, "Click on btninsurancecompany");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnvehicles), "Unable to Click on btnvehicles");
        testLogger.log(Status.PASS, "Click on btnvehicles");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.controlcustody), "Unable to Click on controlcustody");
        testLogger.log(Status.PASS, "Click on controlcustody");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputemailaddress, readPropertiesFileData.getPropertyValue("emailaddress")), "Unable to Insert emailaddress");
        testLogger.log(Status.PASS, "Click on emailaddress");

        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btntravelwithbaby), "Unable to Click on btntravelwithbaby");
        testLogger.log(Status.PASS, "Click on btntravelwithbaby");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnages), "Unable to Click on btnages");
        testLogger.log(Status.PASS, "Click on btnages");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnmedically), "Unable to Click on btnmedically");
        testLogger.log(Status.PASS, "Click on btnmedically");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnmedically1), "Unable to Click on btnmedically1");
        testLogger.log(Status.PASS, "Click on btnmedically1");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.anotherdriver), "Unable to Click on anotherdriver");
        testLogger.log(Status.PASS, "Click on anotherdriver");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");


        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnaccidentclaim), "Unable to Click on btnaccidentclaim");
        testLogger.log(Status.PASS, "Click on btnaccidentclaim");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btndrivinghistory), "Unable to Click on btndrivinghistory");
        testLogger.log(Status.PASS, "Click on btndrivinghistory");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnprosecuted), "Unable to Click on btnprosecuted");
        testLogger.log(Status.PASS, "Click on btnprosecuted");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnapplicationdeclined), "Unable to Click on btnapplicationdeclined");
        testLogger.log(Status.PASS, "Click on btnapplicationdeclined");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnexcessincreased), "Unable to Click on btnexcessincreased");
        testLogger.log(Status.PASS, "Click on btnexcessincreased");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncancelledorrenewal), "Unable to Click on btncancelledorrenewal");
        testLogger.log(Status.PASS, "Click on btncancelledorrenewal");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.Anyperiod), "Unable to Click on Anyperiod");
        testLogger.log(Status.PASS, "Click on Anyperiod");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btninfo), "Unable to Click on btninfo");
        testLogger.log(Status.PASS, "Click on btninfo");

        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnspecialdiscount), "Unable to Click on btnspecialdiscount");
        testLogger.log(Status.PASS, "Click on btnspecialdiscount");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnNonCommissioned), "Unable to Click on btnNonCommissioned");
        testLogger.log(Status.PASS, "Click on btnNonCommissioned");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncamerainstalled), "Unable to Click on btncamerainstalled");
        testLogger.log(Status.PASS, "Click on btncamerainstalled");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnfulltimegovernmentemployee), "Unable to Click on btnfulltimegovernmentemployee");
        testLogger.log(Status.PASS, "Click on btnfulltimegovernmentemployee");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnhomeownerpolicy), "Unable to Click on btnhomeownerpolicy");
        testLogger.log(Status.PASS, "Click on btnhomeownerpolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btninsurerwithpolicy), "Unable to Click on btninsurerwithpolicy");
        testLogger.log(Status.PASS, "Click on btninsurerwithpolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnyearshomeownerpolicy), "Unable to Click on btnyearshomeownerpolicy");
        testLogger.log(Status.PASS, "Click on btnyearshomeownerpolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnbuyhomeownerpolicy), "Unable to Click on btnbuyhomeownerpolicy");
        testLogger.log(Status.PASS, "Click on btnbuyhomeownerpolicy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnIsthisvehiclecurrentlyinsured), "Unable to Click on btnIsthisvehiclecurrentlyinsured");
        testLogger.log(Status.PASS, "Click on btnIsthisvehiclecurrentlyinsured");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnpolicytostart), "Unable to Click on btnpolicytostart");
        testLogger.log(Status.PASS, "Click on btnpolicytostart");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.btnPolicyStartDate, readPropertiesFileData.getPropertyValue("PolicyStartDate")), "Unable to Insert PolicyStartDate");
        testLogger.log(Status.PASS, "Click on PolicyStartDate");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnNCD), "Unable to Click on NCD");
        testLogger.log(Status.PASS, "Click on NCD");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnNCDtovehicle), "Unable to Click on NCDtovehicle");
        testLogger.log(Status.PASS, "Click on NCDtovehicle");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnanothermotorinsurancepolicy), "Unable to Click on another motor insurance policy");
        testLogger.log(Status.PASS, "Click on another motor insurance policy");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnanyartisticpaint), "Unable to Click on any artistic paint");
        testLogger.log(Status.PASS, "Click on any artistic paint");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");*/
        Thread.sleep(2000);
        List<WebElement> clomVal = driver.findElements(QuickQuotefourWheeler.txtcarrier);
        for (int i = 0; i < clomVal.size(); i++) {
            // ArrayList test1 = new ArrayList();
            // test1.add(clomVal.get(i).getText());
            System.out.println("the Value is :\n " + clomVal.get(i).getText());
            if (clomVal.get(i).equals("Your Lowest Quote")) {
                clomVal.get(i).click();
            }
            break;
        }
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnshowquote), "Unable to Click on show quote");
        testLogger.log(Status.PASS, "Click on showquote");

       /* List<WebElement> myList = driver.findElements(By.xpath("//div[@class='comp-comparision-table d-none d-lg-block']//tr[3]//td//span"));
        //To store all web elements into list
        List<String> all_elements_text = new ArrayList<String>();
        for (int i = 0; i < myList.size(); i++) {
            all_elements_text.add(myList.get(i).getText());
            //System.out.println(myList.get(i).getText());
        }
        Object objmin = Collections.min(all_elements_text);
        Object objmax = Collections.max(all_elements_text);

        if (objmin == objmax) {
            //System.out.println("Same lowest value found");
            testLogger.log(Status.PASS, "The Highest value :" + objmax);
            testLogger.log(Status.PASS, "The Lowest value :" + objmin);
        } else {
            //Thread.sleep(2000);
           Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.lowestbuyvalue), "Unable to Click on lowestbuyvalue");
            testLogger.log(Status.PASS, "lowest buy value is :-" + objmin);
        }*/
       // Thread.sleep(2000);
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.lowestbuyvalue), "Unable to Click on lowestbuyvalue");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputTRN, readPropertiesFileData.getPropertyValue("TRN") + commonMethods.getRandomNumber()), "Unable to Insert TRN");
        testLogger.log(Status.PASS, "Click on TRN");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncloseassociateholding), "Unable to Click on closeassociateholding");
        testLogger.log(Status.PASS, "Click on closeassociateholding");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.btnmothermaidenname, readPropertiesFileData.getPropertyValue("Mothername")), "Unable to Insert Mothername");
        testLogger.log(Status.PASS, "Click on Mothername");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputaddress, readPropertiesFileData.getPropertyValue("address")), "Unable to Insert address");
        testLogger.log(Status.PASS, "Click on address");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputstreetnumber, readPropertiesFileData.getPropertyValue("Streetnumber")), "Unable to Insert Streetnumber");
        testLogger.log(Status.PASS, "Click on Streetnumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputstreetname, readPropertiesFileData.getPropertyValue("Streetname")), "Unable to Insert Streetname");
        testLogger.log(Status.PASS, "Click on Streetname");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnIsyourmailingaddress), "Unable to Click on Isyourmailingaddress");
        testLogger.log(Status.PASS, "Click on Isyourmailingaddress");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputcompanyname1, readPropertiesFileData.getPropertyValue("companyname1")), "Unable to Insert companyname");
        testLogger.log(Status.PASS, "Click on companyname");

       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnparish), "Unable to Click on Parish");
        testLogger.log(Status.PASS, "Click on Parish");*/
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.Kingstonlive0), "Unable to Click on Kingstonlive");
        testLogger.log(Status.PASS, "Click on Kingstonlive");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputmobile, readPropertiesFileData.getPropertyValue("mobilenumber")), "Unable to Insert mobilenumber");
        testLogger.log(Status.PASS, "Click on mobilenumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputwork, readPropertiesFileData.getPropertyValue("Worknumber")), "Unable to Insert Worknumber");
        testLogger.log(Status.PASS, "Click on Worknumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputResidential, readPropertiesFileData.getPropertyValue("Residentialnumber")), "Unable to Insert Residentialnumber");
        testLogger.log(Status.PASS, "Click on Residentialnumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputmotorcycleenginenumber, readPropertiesFileData.getPropertyValue("motorcycleenginenumber")), "Unable to Insert motorcycleenginenumber");
        testLogger.log(Status.PASS, "Click on motorcycleenginenumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputmotorcycleChassisnumber, readPropertiesFileData.getPropertyValue("motorcycleChassisnumber")), "Unable to Insert motorcycleChassisnumber");
        testLogger.log(Status.PASS, "Click on motorcycleChassisnumber");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnNextForm), "Unable to Click on btnNextForm");
        testLogger.log(Status.PASS, "Click on btnNextForm");
        //Step 48: Pay Your Premiums
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnsalary), "Unable to Click on Salary");
        testLogger.log(Status.PASS, "Click on Salary");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnfullpayment), "Unable to Click on Full Payment");
        testLogger.log(Status.PASS, "Click on Full Payment");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btncreditcard), "Unable to Click on Credit Card");
        testLogger.log(Status.PASS, "Click on Credit Card");
        Assert.assertTrue(commonMethods.clickByJS(QuickQuotefourWheeler.btnmastercard), "Unable to Click on mastercard");
        testLogger.log(Status.PASS, "Click on Mastercard");

        //Step 48:Creditcardinformation
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputcardname, readPropertiesFileData.getPropertyValue("cardname")), "Unable to Insert cardname");
        testLogger.log(Status.PASS, "Card Name is :-" + readPropertiesFileData.getPropertyValue("cardname"));
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputcardnumber, readPropertiesFileData.getPropertyValue("cardnumber")), "Unable to Insert cardnumber");
        testLogger.log(Status.PASS, "Card Number is :-" + readPropertiesFileData.getPropertyValue("cardnumber"));
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btndropclickmonth), "Unable to Click on DropDown Month");
        //test.log(Status.PASS, "Click on Month");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.drpcardmonth), "Unable to Click on cardmonth");
        testLogger.log(Status.PASS, "Click on cardmonth");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btndropclick), "Unable to Click on Month");
        testLogger.log(Status.PASS, "Click on Month");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.drpcardyear), "Unable to Click on Year");
        testLogger.log(Status.PASS, "Click on Year");
        Assert.assertTrue(commonMethods.enterTextInInputField(QuickQuotefourWheeler.inputsecuritycode, readPropertiesFileData.getPropertyValue("securitycode")), "Unable to Insert cardnumber");
        testLogger.log(Status.PASS, "Security Code is :-" + readPropertiesFileData.getPropertyValue("securitycode"));
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(QuickQuotefourWheeler.btnNextForm), "Unable to Click on NextForm");
        testLogger.log(Status.PASS, "Click on NextForm");
        Thread.sleep(5000);
        Assert.assertTrue(commonMethods.verifyElementIsVisible(QuickQuotefourWheeler.thankyou), "Unable to Click your payment was successful!");
        testLogger.log(Status.PASS, "Your Payment Was Successful!");


    }
}